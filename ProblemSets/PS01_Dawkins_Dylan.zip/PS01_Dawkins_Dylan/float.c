#include<stdio.h>

int main (void)
{
	//prints the float values 1.0, 0.5, 0.1
	printf("%.20f\n", 1.0f);
	printf("%.20f\n", 0.5f);
	printf("%.20f\n", 0.1f);
}