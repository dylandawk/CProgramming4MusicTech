#include <stdio.h>

int main (void)
{
	//prints "Hello World"
    puts("Hello World! \n");
    return 0;
}