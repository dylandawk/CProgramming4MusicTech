#include<stdio.h>

int main (void)
{
	//prints the double values 1.0, 0.5, 0.1
	printf("%.20f\n", 1.0);
	printf("%.20f\n", 0.5);
	printf("%.20f\n", 0.1);
}